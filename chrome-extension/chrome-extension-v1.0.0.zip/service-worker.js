const e=()=>{console.log("Service worker installed.")};e();
