console.log("Service worker installed.");
